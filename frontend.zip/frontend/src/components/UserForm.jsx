import React, { useState, useEffect } from 'react'
import { useNavigate, useLocation } from 'react-router';

const UserForm = () => {
    const [form, setForm] = useState({ name: "", email: "", age: "" });
    const [message, setMessage] = useState('')
    const navigate = useNavigate()
    const location = useLocation()
    const isEditing = location.state?.user
    const userId = isEditing?._id
    const handleChange = (e) => {
        setForm({ ...form, [e.target.name]: e.target.value });
    };

    useEffect(() => {
        if (isEditing) {
            setForm({ name: isEditing.name, email: isEditing.email, age: isEditing.age })
        }
    }, [isEditing])

    const validateForm = () => {
        if (!form.name.trim()) return 'Name is required'
        if (!form.email.trim()) return 'Email is required'
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) return 'Invalid email format'
        if (!form.age || form.age <= 0) return 'Valid age is required'
        return null
    }

    const handleSubmit = async(e) => {
        e.preventDefault()
        const error = validateForm()
        if (error) {
            setMessage(error)
            return
        }
        try{
            const url = isEditing ? `http://localhost:5000/api/${userId}` : "http://localhost:5000/api/save"
            const method = isEditing ? "PUT" : "POST"
            const res = await fetch(url,
                {
                    method,
                    headers:{'content-type':'application/json'},
                    body:JSON.stringify(form)
                }
            )
             
            if (!isEditing) setForm({ name: "", email: "", age: "" })
            setTimeout(() => navigate("/view"), 2000)
        }
        catch(err){
            setMessage(err.message)
        }
    }

    return (
        <>
            {message && <p style={{color: message.includes('successfully') ? 'green' : 'red'}}>{message}</p>}
            <form onSubmit={handleSubmit} style={{ marginBottom: "30px" }}>
                <label htmlFor="name" style={{display:'inline-block',width:'80px'}}>Name</label>
                <input name="name" value={form.name} onChange={handleChange} required /><br /><br />
                <label htmlFor="email" style={{display:'inline-block',width:'80px'}}>Email</label>
                <input name="email" type="email" value={form.email} onChange={handleChange} required /><br /><br />
                <label htmlFor="age" style={{display:'inline-block',width:'80px'}}>Age</label>

                <input name="age" type="number" value={form.age} onChange={handleChange} required min="1" /><br /><br />
                <button type="submit">{isEditing ? 'Update User' : 'Add User'}</button>
            </form>
        </>
    )
}

export default UserForm
