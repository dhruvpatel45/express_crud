import React from 'react'

const Home = () => {
  return (
    <div>
      User Crud
    </div>
  )
}

export default Home
