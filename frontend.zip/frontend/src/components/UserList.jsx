import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router'

const UserList = () => {
      const [users, setUsers] = useState([])
      const [error, setError] = useState('')
      const navigate = useNavigate()

      const fetchUsers = async()=>{
        try{
          const res = await fetch("http://localhost:5000/api")
          const data = await res.json()
          setUsers(data)
        }
        catch(e){
          setError(e.message)
        }
      }

      const handleDelete = async(id)=>{
        try{
          const res = await fetch(`http://localhost:5000/api/${id}`, {method:'DELETE'})
          fetchUsers() 
        }
        catch(e){
          setError(e.message)
        }
      }

      useEffect(()=>{fetchUsers()},[])
  return (
    <div>
      <h3>User List</h3>
      {error && <p style={{color:'red'}}>{error}</p>}
      <table border="1" cellSpacing={0}>
        <thead>
            <tr>
                <th>Name</th><th>Email</th><th>Age</th><th>Action</th>
            </tr>
        </thead>
        <tbody>
            {users.length === 0 ? <tr><td colSpan={4}>No users found</td></tr>
            :
            <>
        {users.map((user) =>
            <tr key={user._id}>
                <td>{user.name}</td>
                <td>{user.email}</td>
                <td>{user.age}</td>
                <td><button onClick={()=>navigate('/add', {state: {user}})}>Edit</button>{" "}
              <button onClick={()=>handleDelete(user._id)}>Delete</button></td>
            </tr>)}
            </>
            }
        </tbody>
      </table>



    </div>
  )
}

export default UserList
