import mongoose from 'mongoose';
const UserSchema = mongoose.Schema(
    {
        name:{type:String,required:true},
        email:{type:String,required:true},
        age:{type:Number}
    }
)
const User = mongoose.model("user",UserSchema)
export default User